package day02;

public class Hello0310 {

	public static void main(String[] args) {
		//print 계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력 하기
		//자바로 자기소개 하기
		System.out.println("자바를 이용해서 자기소개 하기");
		System.out.println("취미 : 영화보기");
		//System.out.println("고향 : 전주");
		System.out.print("이름 : 정성훈\n나이 : 비밀");
	}

}

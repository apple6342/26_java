package day02;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//한글 주석
		//System.out.println("Hello Java~~");
		System.out.print("반갑습니다. 열심히 java 공부해요\n줄바꼈습니다.");
		System.out.print("반갑습니다. 열심히 java 공부해요\\n줄바꼈습니다.");
		//System.out.println("정성훈");
	}

}

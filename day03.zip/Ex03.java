package day03;
import java.util.Scanner;
public class Ex03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 입력하세요");
		int num=sc.nextInt();
		int n = num % 2; //짝수 홀수 판단 수식
		
		String result = (n ==0) ? "짝수" : "홀수";
		
		System.out.println(result);
	}

}

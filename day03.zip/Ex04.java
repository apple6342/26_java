package day03;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//id pwd 초기화
		String id="jeong", pwd="0070";		
		System.out.println("아이디를 입력하세요: ");
		String myid = scan.next();
		
		System.out.println("비밀번호를 입력하세요: ");
		String myPwd = scan.next();
		
		if (myid.equals(id) && myPwd.equals(pwd)) {			
			//참일떄 실행문
			System.out.println("로그인 성공");
		}else {
			System.out.println("로그인 실패");
		}
	}

}

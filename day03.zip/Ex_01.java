package day03;

import java.util.Scanner;

public class Ex_01 {

	public static void main(String[] args) {
		int age;
		String name = new String();
		//변수 초기화 
		age = 20;
		name = "정성훈";
		
		
		
		//Scanner 객체 생성
		Scanner scan = new Scanner(System.in);
		System.out.println("나이를 입력하세요: ");
		age = scan.nextInt();
		System.out.println("이름을 입력하세요: ");
		name = scan.next();
		System.out.println("나이:" + age);
		System.out.println("이름:" + name);
		
		System.out.print("나이는" + age + "살, ");
	}

}

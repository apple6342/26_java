package day04;

import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		
	
		Scanner scan = new Scanner(System.in); 
		
		int age;
		System.out.print("나이를 입력하세요: ");
		age = scan.nextInt();
		
		if (age < 18) {			
			// 참일때 실행문
			System.out.println("관람 가능");
		} else {
			System.out.println("청소년 관람 불가");
		}
				
	} 

} 
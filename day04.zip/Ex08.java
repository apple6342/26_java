package day04;

import java.util.Scanner; // Scanner를 사용하기 위한 import 문 추가

public class Ex08 {
    // 무한반복해서 정수를 입력한 후 음수가 입력되면 무한반복을 종료하고,
    // 누적의 합을 출력하기.
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int sum = 0;
        
        System.out.println("정수를 입력하세요 (음수 입력 시 종료):");
        
        while(true) {
            // 사용자로부터 정수를 입력받아 변수 num에 저장
            int num = scan.nextInt(); 
            
            if(num < 0) {
                break; // 음수이면 반복문을 완전히 종료함 (continue 대신 break 사용)
            } else {
                sum = sum + num; // 양수나 0이면 sum에 누적
            }
        }
        
        System.out.println("합은 : " + sum);
        scan.close();
    }
}
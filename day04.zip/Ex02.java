package day04;

import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		
	
		Scanner scan = new Scanner(System.in); 
		int balance = 10000;
		System.out.print("나이를 입력하세요");
		int age = scan.nextInt();
		
		
		if (age>=19) {			
			// 참일때 실행문
			balance -=1200;
			System.out.println("일반 : "+balance);
		} else if(age>=13){
			balance -=720;
			System.out.println("중고등학생 : " + balance);
		}
		else if(age>=7){
			balance -=450;
			System.out.println("초등학생 : " + balance);

		}
				
	} 

} 
package day04;

import java.util.Scanner;

public class Ex06 {
    public static void main(String[] args) {
        int count = 0; // 입력된 정수의 개수를 저장할 변수
        int sum = 0;   // 입력된 정수들의 합을 저장할 변수
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("정수를 입력하고 마지막에 -1을 입력하세요.");

        int n = scanner.nextInt(); // 첫 번째 정수 입력 받기
        
        // -1이 입력될 때까지 계속해서 반복
        while(n != -1) { 
            sum += n; // 입력받은 값을 합계에 더함
            count++;  // 입력받은 개수를 1 증가시킴
            n = scanner.nextInt(); // 다음 정수 입력 받기
        }
        
        // 반복문 종료 후 결과 출력
        if(count == 0) {
            System.out.println("입력된 수가 없습니다.");
        } else {
            System.out.print("정수의 개수는 " + count + "개이며 ");
            // 정확한 소수점 결과를 얻기 위해 sum을 double로 형변환
            System.out.println("평균은 " + (double)sum/count + "입니다.");
        }
        
        scanner.close();
    }
}
package day04;

public class Ex07 {
    public static void main(String[] args) {
        
        for(int i = 1; i < 10; i++) { // 1단에서 9단까지 (바깥쪽 반복문)
            
            for(int j = 1; j < 10; j++) { // 각 단의 곱하기 1~9 (안쪽 반복문)
                System.out.print(i + "*" + j + "=" + (i * j)); // 구구셈 출력
                System.out.print('\t'); // 탭(Tab) 만큼 띄어쓰기
            }
            
            System.out.println(); // 한 단의 출력이 끝나면 다음 줄로 이동 (줄바꿈)
        }
        
    }
}
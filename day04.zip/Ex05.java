package day04;

public class Ex05 {

	public static void main(String[] args) {
		/*
		//1부터 10까지의 합을 계산하는 for반복문 아넝
		int sum = 0;
		for(int i = 1; i<=10; i++) {
			sum = sum+i;
			//System.out.print(i)
		}
		System.out.println(sum);
	}
*/
		int i = 1; //초기식
		int sum = 0;
		while(i<=100) {
			sum = sum+i;
			i++;
		}
		System.out.println(sum);
}
}
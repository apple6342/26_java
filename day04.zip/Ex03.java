package day04;

import java.util.Scanner;

public class Ex03 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("가위 바위 보 게임입니다. 가위 바위 보 중에서 입력하세요.");
        
        System.out.print("철수 입력 >>> ");
        String user1 = scanner.next();
        System.out.println("철수 >>> " + user1);
        
        System.out.print("영희 입력 >>> ");
        String user2 = scanner.next();
        System.out.println("영희 >>> " + user2);
        
        // 철수가 낸 것을 먼저 확인하는 중첩 if문 구조
        if (user1.equals("보")) { // 철수가 '보'를 냈을 때
            if (user2.equals("보")) {
                System.out.println("비겼습니다.");
            } else if (user2.equals("바위")) {
                System.out.println("철수가 이겼습니다.");
            } else if (user2.equals("가위")) {
                System.out.println("영희가 이겼습니다.");
            }
        } 
        else if (user1.equals("가위")) { // 철수가 '가위'를 냈을 때
            if (user2.equals("가위")) {
                System.out.println("비겼습니다.");
            } else if (user2.equals("보")) {
                System.out.println("철수가 이겼습니다.");
            } else if (user2.equals("바위")) {
                System.out.println("영희가 이겼습니다.");
            }
        } 
        else if (user1.equals("바위")) { // 철수가 '바위'를 냈을 때
            if (user2.equals("바위")) {
                System.out.println("비겼습니다.");
            } else if (user2.equals("가위")) {
                System.out.println("철수가 이겼습니다.");
            } else if (user2.equals("보")) {
                System.out.println("영희가 이겼습니다.");
            }
        } 
        else {
            System.out.println("가위, 바위, 보 중에서 올바르게 입력해주세요.");
        }
        
        scanner.close();
    }
}
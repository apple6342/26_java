package day05;

import java.util.Scanner; // 1. Scanner 클래스 import 추가

public class Ex02 {

	public static void main(String[] args) {
		// 1차원 배열
		int intArray [];
		// 배열 생성
		intArray = new int[5];
		int intMax = 0; // 2. 에러 방지를 위해 초기값 0으로 설정
		
		Scanner scan = new Scanner(System.in);
		
		// 양수 5개 입력 받아 배열에 저장하고, 그 중 가장 큰 수 출력하기
		System.out.println("양수 5개를 입력하세요.");
		for(int i = 0; i < 5; i++) {
            intArray[i] = scan.nextInt(); // 입력받은 정수를 배열에 저장
            
            if(intArray[i] > intMax) { // intArray[i]가 현재 가장 큰 수보다 크면
                intMax = intArray[i];  // intArray[i]를 intMax로 변경
            }
        }
        
        System.out.print("가장 큰 수는 " + intMax + "입니다.");
        
        scan.close(); // Scanner 사용이 끝난 후 닫아주는 것이 좋습니다.

	}

}
package day05;

import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		// 1차원 배열 생성
		int intArray[] = new int[5];
		
		int sum = 0; // 합계를 저장할 변수 초기화
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("양수 5개를 입력하세요.");
		for(int i = 0; i < 5; i++) {
			intArray[i] = scan.nextInt(); // 입력받은 정수를 배열에 저장
			sum += intArray[i];           // 입력받은 값을 sum에 누적해서 더하기
		}
		
		// 평균 계산
		// 정수(int)끼리 나누면 소수점 이하가 버려지므로, 정확한 계산을 위해 (double)로 형변환
		double average = (double) sum / intArray.length; 
        
		System.out.println("입력한 수의 합계는 " + sum + "입니다.");
		System.out.println("입력한 수의 평균은 " + average + "입니다.");
        
		scan.close();
	}

}